<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Mariana 2 Mars</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Reenie Beanie' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
</head>
</head>

<body>
    <header class="container-fluid">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-9 col-md-3" style="display: flex;align-items: center;">
                    <img src="assets/logo.png" class="logo">
                </div>
                <div class="menu-box col-3 col-md-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                    <button onclick="$('.navigation').addClass('open');" style="background:#F51720 ;" class="d-md-none rounded main-btn-bk border-0 py-2 px-4 text-white"><i class="fas fa-bars"></i></button>
                    <nav class="navigation" id="navigationmenu">
                        <button class="d-md-none" onclick="$('.navigation').removeClass('open'); $('.sub-menu').slideUp().removeClass('active');
                    $('.has-drop').removeClass('active-a');" style="    position: absolute;right: 19px;border: 0;background: transparent;color: white;top: 14px;font-size: 16px;"><i class="fas fa-arrow-right"></i></button>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about-us.php">About Us</a></li>
                            <li>
                                <a data-id="service" class="has-drop">Services</a>
                                <ul data-id="service" class="sub-menu">
                                <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                    <li><a href="marketings.php">Marketing</a></li>
                                    <!-- <li><a href="product-discovery.php">Product Discovery</a></li>
                                    <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    <li><a href="intrnet-things.php">Internet of Things</a></li>
                                    <li><a href="blockchain.php">Blockchain</a></li>
                                    <li><a href="extended-reality.php">Extended Reality</a></li>
                                    <li><a href="protoyping.php">Prototyping</a></li>
                                    <li><a href="ux-dsign.php">UX Design</a></li> -->
                                </ul>
                            </li>
                            <li><a href="clients.php">clients</a></li>
                            <li><a href="our-team.php">Our Team</a></li>
                            <li><a href="contact-us.php">Conatct Us</a></li>
                            <li><a href="#" class="main-btn-red">Consult</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <div class="container-fluid inner-banner p-0 position-relative">
        <img src="assets/banner-1.png">
        <div class="container position-relative h-100">
            <div class="row h-100 align-items-center justify-content-centr">
                <div style="z-index:1;">
                    <h3 class="inner-banner-head">Contact Us</h3>
                </div>
            </div>
        </div>
    </div>
    <div class="containr-fluid py-6 testi">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-3 content-box">
                    <div class="contact-wise-image one">
                        <i class="fas fa-map-marker"></i>
                    </div>
                    <h5>ADDRESS</h5>
                    <p>7 BAYVIEW STATION ROAD OTTAWA, ON CANADA</p>
                </div>
                <div class="col-12 col-md-3 mt-4 mt-md-0 content-box">
                    <div class="contact-wise-image two">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h5>EMAIL</h5>
                    <p>INFO@MARIANA2MARS.COM</p>
                </div>
                <div class="col-12 col-md-3 mt-4 mt-md-0 content-box">
                    <div class="contact-wise-image three">
                        <i class="fas fa-phone"></i>
                    </div>
                    <h5>PHONE</h5>
                    <p>(514) 910-1418</p>
                </div>
                <div class="col-12 col-md-3 mt-4 mt-md-0 content-box">
                    <div class="contact-wise-image four">
                        <i class="fas fa-globe"></i>
                    </div>
                    <h5>WEBSITE</h5>
                    <p>www.mariana2mars.com</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid reach-us py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-10 offset-md-1">
                    <h2 class="heading mb-5 text-center">Reach <span class="under-dec">Us</span></h2>
                    <div class="col-12 reachus-box">
                        <form id="contactForm" class="row m-0 p-0" action="contact_message_process.php" method="POST">
                            <div class="col-12 col-md-4 form-group ">
                                <div class="col-12 input-from-group rounded">

                                    <input type="text" class="form-control" id="cname" name="cname" placeholder="Name">
                                </div>
                            </div>
                            <div class="col-12 col-md-4 form-group ">
                                <div class="col-12 input-from-group rounded">

                                    <input type="text" class="form-control" id="cemail" name="cemail" placeholder="Email Id">
                                </div>
                            </div>
                            <div class="col-12 col-md-4 form-group ">
                                <div class="col-12 input-from-group rouned">

                                    <input type="text" class="form-control" id="cphone" name="cphone" placeholder="Phone">
                                </div>
                            </div>
                            <div class="col-12 form-group ">
                                <div class="col-12 input-from-group ">
                                    <textarea class="form-control msg" rows="4" id="ccomment" name="ccomment" placeholder="Message"></textarea>
                                </div>
                            </div>
                            <div class="col-12 mb-0 form-group text-center mt-4 mt-md-0">
                                <button type="submit" class="border-0 main-btn-red" id="submit">Submit</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3330.784207924013!2d-75.72842689412022!3d45.412475180164805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cce04402bbd31e3%3A0x5f8afa5e5dcf7cfe!2sBayview%20Yards!5e0!3m2!1sen!2sin!4v1663048753112!5m2!1sen!2sin" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    <div class="container-fluid footer py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 ft-top mb-5 d-md-flex align-items-center">
                    <img src="assets/logo.png" class="logo">
                    <h3>Modern Solutionsd For Creative <span>Agency</span></h3>
                </div>
                <div class="col-12 col-md-5 get-in">
                    <h4>Get in touch!</h4>
                    <p>Fusce varius, dolor tempor interdum tristique, dui urna bibendum magna, ut ullamcorper purus</p>
                    <div class="sub-frm-cell">
                        <input type="text" placeholder="Enter Mobile Number">
                        <button>Subscribe</button>
                    </div>
                </div>
                <div class="col-12 col-md-7 menu-link pl-md-5 ">
                    <div class="row">
                        <div class="col-md-7 mt-5 mt-md-0">
                            <h5>Services</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-md-2">
                                    <ul>
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    
                                        <!-- <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li> -->
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                    <li><a href="marketings.php">Marketing</a></li>
                                        <!-- <li><a href="intrnet-things.php">Internet of Things</a></li>
                                        <li><a href="blockchain.php">Blockchain</a></li>
                                        <li><a href="extended-reality.php">Extended Reality</a></li>
                                        <li><a href="protoyping.php">Prototyping</a></li>
                                        <li><a href="ux-dsign.php">UX Design</a></li> -->
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-5  pl-md-5 mt-5 mt-md-0">
                            <h5>Links</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-2">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="service.php">Services</a></li>
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <li><a href="clients.php">clients</a></li>
                                        <li><a href="our-team.php">Our Team</a></li>
                                        <li><a href="contact-us.php">Conatct Us</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="footer-social d-md-flex align-items-center justify-content-between pt-5 mt-5 rounded">
                    <p class="mb-0" style="font-size:15px;">Copyright @ 2014 - 2022 </a></p>
                    <p class="mb-0" style=" font-size:15px;">
                        <a style=" margin-right:10px;margin-left:10px;"><i class="fab fa-facebook"></i></a>
                        <a style="  margin-right:10px;"><i class="fab fa-instagram"></i></a>
                        <a><i class="fab fa-twitter"></i></a>
                    </p>

                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $(document).ready(function() {
        $('.has-drop').click(function() {
            if ($(".sub-menu[data-id='" + $(this).attr('data-id') + "']").hasClass("active")) {
                $(".sub-menu").slideUp().removeClass('active');
                $(".has-drop").removeClass('active-a');
            } else {
                $(".sub-menu").slideUp().removeClass('active');
                $(".sub-menu[data-id='" + $(this).attr('data-id') + "']").slideDown().addClass("active");
                $(".has-drop").removeClass('active-a');
                $(this).parent().find(".has-drop").addClass('active-a');
            }
        });
    });
</script>

</html>