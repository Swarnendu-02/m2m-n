<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Mariana 2 Mars</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Reenie Beanie' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
</head>
</head>

<body>
<header class="container-fluid">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-9 col-md-3" style="display: flex;align-items: center;">
                    <img src="assets/logo.png" class="logo">
                </div>
                <div class="menu-box col-3 col-md-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                    <button onclick="$('.navigation').addClass('open');" style="background:#F51720 ;" class="d-md-none rounded main-btn-bk border-0 py-2 px-4 text-white"><i class="fas fa-bars"></i></button>
                    <nav class="navigation" id="navigationmenu">
                        <button class="d-md-none" onclick="$('.navigation').removeClass('open'); $('.sub-menu').slideUp().removeClass('active');
                    $('.has-drop').removeClass('active-a');" style="    position: absolute;right: 19px;border: 0;background: transparent;color: white;top: 14px;font-size: 16px;"><i class="fas fa-arrow-right"></i></button>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about-us.php">About Us</a></li>
                            <li>
                                <a data-id="service" class="has-drop">Services</a>
                                <ul data-id="service" class="sub-menu">
                                <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                   <li><a href="marketings.php">Marketing</a></li>
                                    <!-- <li><a href="product-discovery.php">Product Discovery</a></li>
                                    <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    <li><a href="intrnet-things.php">Internet of Things</a></li>
                                    <li><a href="blockchain.php">Blockchain</a></li>
                                    <li><a href="extended-reality.php">Extended Reality</a></li>
                                    <li><a href="protoyping.php">Prototyping</a></li>
                                    <li><a href="ux-dsign.php">UX Design</a></li> -->
                                </ul>
                            </li>
                            <li><a href="clients.php">clients</a></li>
                            <li><a href="our-team.php">Our Team</a></li>
                            <li><a href="contact-us.php">Conatct Us</a></li>
                            <li><a href="#" class="main-btn-red">Consult</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <div class="container-fluid inner-banner p-0 position-relative">
        <img src="assets/banner-1.png">
        <div class="container position-relative h-100">
            <div class="row h-100 align-items-center justify-content-centr">
                <div style="z-index:1;">
                    <h3 class="inner-banner-head">Custom Web Development</h3>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row align-items-center">
                <div class="col-12 col-md-6">
                    <div class="col-12 main-heaing">
                        <h2>Building Agile <span>Web Experiences</span></h2>
                    </div>
                    <div class="col-12 service-wrap">
                        <div class="content">
                            <p>Creating quality products and services essential to running a successful startup—but building a unique web experience for your customers is what connects them to your business and brand. 
                                <br><br>
                                With M2M’s strategic web development services, we build technical solutions that drive business, increase your authority, and bring your vision for the future of your business to life. Our team of expert web app designers and developers will build you a custom website from scratch—or revise and optimize your existing site. We embody your brand to ensure consistency, quality, and familiarity for your target audience.

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 about-counter-cell ">
                    <div class="mobile-dev-top-lft">
                        <ul>
                            <li>Build a fully-functional, customizable, UI, UX-incorporated website solution that includeseCommerce functionality</li>
                            <li>Custom SaaS web solutions enable your business to create an accessible user interface and web portal that enhance the customer experience</li>
                            <li>Simplify content creation, storage, organization, editing, and publishing with a customized content management system</li>
                            <li>Utilize custom dashboards and business intelligence tools for more effective data analysis and decision-making</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid position-relative py-6">
        <div class="process-bk">
            <img src="assets/proccss-bk.png">
        </div>
        <div class="container position-relative">
            <div class="row">
                <p class="mb-0 text-white text-center" style="font-size:20px ;">M2M collaborate with our clients to fully understand their brand values and the core purpose, mission, and vision of their business. Our knowledge of your story and brand history enables us to create a web presence that positively promotes your organization and builds trust with your target audience. Our diverse range of technologies, including Java, Drupal, and PHP, are used by our team of experts to create a unique and informative website that drives traffic and builds engagement.</p>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2>Our <span>Web Development</span> Service Offerings</h2>
                </div>
                <div class="col-12 service-wrap">
                    <div class="owl-carousel owl-theme service-owl">
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Web Portal Development</h4>
                                    <p class="mb-0">Our custom web development services give your business a simple and easy-to-navigate web portal. Your custom solution not only provides users with a personalized and interactive web experience, but the design and functionality are based on the specific needs of your business.</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Executive Dashboard Development</h4>
                                    <p class="mb-0">Focus on the metrics that matter and give your business executives the data they need—when they need it. Our innovative executive dashboards display data and information in a way that is easily-consumable and relevant to real-time behaviours and experiences of your customers. </p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>SaaS Development</h4>
                                    <p class="mb-0">To stay relevant in today’s digitalized marketplace, SaaS businesses need to bridge the gap between their mobile apps, cloud hosting, and data storage solutions. Our expert developers work with you to develop SaaS web solutions that keep your business current and competitive. </p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>User Experience Design</h4>
                                    <p class="mb-0">Distinguish your business from the competition with a consistent consumer-centric user experience throughout your website. We work with you to view the web experience from your visitor’s perspective—integrating empathy and simplicity into your site’s UI/UX. This experience-based design methodology helps attract and retain customers. 
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>24/7 Maintenance and Support</h4>
                                    <p class="mb-0">Our DevOps team provides 24/7 support and maintenance services for your website. Our consistent support model ensures that your website remains active and customers receive a consistent user experience every time they visit.</p>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Custom eCommerce Development Services</h4>
                                    <p class="mb-0">Our native iOS app development services allow your business to successfully launch a web application across multiple devices including iPhone, iPad, Apple Watch, and Apple TV platforms. Our eCommerce apps are custom-designed to align with your business and security requirements.</p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Enterprise Web Solutions</h4>
                                    <p class="mb-0">Our custom CMS solutions optimize content creation, storage, organization, editing, and publishing. Ourexpert developers leverage innovative technology to personalize solutions, enhance the user experience, and create useful and measurable analytics.</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Custom CMS Development</h4>
                                    <p class="mb-0">Set yourself apart from the competition through a customer-centric user experience throughout your website. Integrate empathy, design thinking and ease into your UI/UX and attract and retain customers.</p>

                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <img src="assets/service (1).png" class="icon-cell position-relative mb-3" style="transform: translate(0,0); right:0; top:0;margin:auto; top:0;margin:auto;">
                                    <h4>Open Source CMS Solutions</h4>
                                    <p class="mb-0">Our innovative development teams leverage progressive apps to create an immersive user experience. With a similar look and feel asa mobile app, our open-source CMS enables dynamic upgrades and responsiveness while simplifying the user experience. Your customized online presence gives your target audience a modern and convenient way to engage and interact with your business.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid position-relative py-6">
        <div class="process-bk">
            <img src="assets/proccss-bk.png">
        </div>
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center text-white">How Our  <span class="text-white">Web App Development</span> Services Benefit Your Business</h2>
                </div>
                <p class="mb-0 text-white text-center" style="font-size:20px ;">Your business needs an experienced web app development company that understand the unique requirements of startups and how their websites can be customized to provide maximum value—to their bottom line and customers. With over 1000 successful projects and 500 satisfied clients, our expertise gives you confidence to make informed decisions and move forward with the development of your web application.</p>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6" style="background:#F51720;">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center text-white">Delivery Process For Custom  <span class="text-white">Web Development</span></h2>
                </div>
                <div class="col-12 col-md-8 offset-md-2 app-dev-box web-dev-cell">
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">1</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Understanding Client Vision</h4>
                                <p class="mb-0 text-left">We work with you to understand the vision you have for your website and how you want it to function from both a business and user perspective. Our knowledge and experience allow us to suggest the optimal web solutions for your needs.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">2</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Planning and Conceptualization</h4>
                                <p class="mb-0 text-left">To bring your vision to life, our expert design teams plan and conceptualize the look, feel, and functionality of your website. Our seasoned project managers define clear milestones and timelines to keep the project on track and organized.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">3</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Designing and Development</h4>
                                <p class="mb-0 text-left">Our functional models and wireframes allow you to envision your ideas in action throughout the development process. We design your website’s custom code based on your reviews and feedback of the mock-up environment.</p>
                            </div>
                        </div>
                    </div>

                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">4</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Testing</h4>
                                <p class="mb-0 text-left">To ensure functionality of your website across multiple devices, we thoroughly test and run your website on Android, iOS, and Windows platforms. We test to verify that the code is secure and that the end user experience is seamless and engaging. </p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">5</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Launch</h4>
                                <p class="mb-0 text-left">After our rigorous testing and ensuring that your website is ready for visitors, we launch it by deploying to a server. To ensure a broach reach and engagement with your site from the first day, our marketing team will promote your business, products, and services to your target audience.</p>
                            </div>
                        </div>
                    </div>
                    <div class="service-box p-0  text-white">
                        <div class="service-cell bg-transparent d-md-flex" style="overflow:hidden;">
                            <i class="web-why-i">6</i>
                            <div class="web-del-box">
                                <h4 class="text-left">Maintenance and Support</h4>
                                <p class="mb-0 text-left">Any performance issues or upgrades needed after deployment are handled by our 24/7 maintenance and support team. Our experienced professionals will plan, schedule, and facilitate changes in a way that minimizes operational disruptions and keeps customers connected.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row py-6 border-top">
                <div class="owl-carousel owl-theme tec-owl">
                    <div class="item">
                        <img src="assets/python.png">
                        <p>PYTHON DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/React-icon.svg.png">
                        <p>REACT DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/2048px-Angular_full_color_logo.svg.png">
                        <p>ANGULAR DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/PHP-logo.svg.png">
                        <p>PHP DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/ntffgniiqfya5tvzbsol.webp">
                        <p>FRONTEND DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/1200px-Wordpress_Blue_logo.png">
                        <p>WORDPRESS DEVELOPMENT</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5" style="background: #42424A;">
        <div class="container">
            <div class="row">
                <div class="con-box">
                    <div class="con-cell">
                        <h3>Need a successful project?</h3>
                        <p>call us now</p>
                        <h3>(514) 910-1418</h3>
                    </div>
                    <button class="main-btn-white border-white">Consult</button>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid footer py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 ft-top mb-5 d-md-flex align-items-center">
                    <img src="assets/logo.png" class="logo">
                    <h3>Modern Solutionsd For Creative <span>Agency</span></h3>
                </div>
                <div class="col-12 col-md-5 get-in">
                    <h4>Get in touch!</h4>
                    <p>Fusce varius, dolor tempor interdum tristique, dui urna bibendum magna, ut ullamcorper purus</p>
                    <div class="sub-frm-cell">
                        <input type="text" placeholder="Enter Mobile Number">
                        <button>Subscribe</button>
                    </div>
                </div>
                <div class="col-12 col-md-7 menu-link pl-md-5 ">
                    <div class="row">
                        <div class="col-md-7 mt-5 mt-md-0">
                            <h5>Services</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-md-2">
                                    <ul>
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    
                                        <!-- <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li> -->
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                    <li><a href="marketings.php">Marketing</a></li>
                                        <!-- <li><a href="intrnet-things.php">Internet of Things</a></li>
                                        <li><a href="blockchain.php">Blockchain</a></li>
                                        <li><a href="extended-reality.php">Extended Reality</a></li>
                                        <li><a href="protoyping.php">Prototyping</a></li>
                                        <li><a href="ux-dsign.php">UX Design</a></li> -->
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-5  pl-md-5 mt-5 mt-md-0">
                            <h5>Links</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-2">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="service.php">Services</a></li>
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <li><a href="clients.php">clients</a></li>
                                        <li><a href="our-team.php">Our Team</a></li>
                                        <li><a href="contact-us.php">Conatct Us</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="footer-social d-md-flex align-items-center justify-content-between pt-5 mt-5 rounded">
                    <p class="mb-0" style="font-size:15px;">Copyright @ 2014 - 2022 </a></p>
                    <p class="mb-0" style=" font-size:15px;">
                        <a style=" margin-right:10px;margin-left:10px;"><i class="fab fa-facebook"></i></a>
                        <a style="  margin-right:10px;"><i class="fab fa-instagram"></i></a>
                        <a><i class="fab fa-twitter"></i></a>
                    </p>

                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $('.tec-owl').owlCarousel({
        loop: true,
        margin: 50,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 6
            }
        }
    })

    $('.service-owl').owlCarousel({
        loop: true,
        margin: 60,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        dots: false,
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            600: {
                items: 1,
                nav: false,
            },
            1000: {
                items: 3,
                nav: true,
            }
        }
    })
</script>
<script>
    $(document).ready(function() {
        $('.has-drop').click(function() {
                if ($(".sub-menu[data-id='" + $(this).attr('data-id') + "']").hasClass("active")) {
                    $(".sub-menu").slideUp().removeClass('active');
                    $(".has-drop").removeClass('active-a');
                } else {
                    $(".sub-menu").slideUp().removeClass('active');
                    $(".sub-menu[data-id='" + $(this).attr('data-id') + "']").slideDown().addClass("active");
                    $(".has-drop").removeClass('active-a');
                    $(this).parent().find(".has-drop").addClass('active-a');
                }
            });
    });
</script>
</html>