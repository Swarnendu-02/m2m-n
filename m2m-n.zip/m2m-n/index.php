<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Mariana 2 Mars</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Reenie Beanie' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <script src="js/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
</head>
</head>

<body>
    <header class="container-fluid">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-9 col-md-3" style="display: flex;align-items: center;">
                    <img src="assets/logo.png" class="logo">
                </div>
                <div class="menu-box col-3 col-md-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                    <button onclick="$('.navigation').addClass('open');" style="background:#F51720 ;" class="d-md-none rounded main-btn-bk border-0 py-2 px-4 text-white"><i class="fas fa-bars"></i></button>
                    <nav class="navigation" id="navigationmenu">
                        <button class="d-md-none" onclick="$('.navigation').removeClass('open'); $('.sub-menu').slideUp().removeClass('active');
                    $('.has-drop').removeClass('active-a');" style="    position: absolute;right: 19px;border: 0;background: transparent;color: white;top: 14px;font-size: 16px;"><i class="fas fa-arrow-right"></i></button>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about-us.php">About Us</a></li>
                            <li>
                                <a data-id="service" class="has-drop">Services</a>
                                <ul data-id="service" class="sub-menu">
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                   <li><a href="marketings.php">Marketing</a></li>
                                    <!-- <li><a href="product-discovery.php">Product Discovery</a></li>
                                    <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li>
                                    <li><a href="intrnet-things.php">Internet of Things</a></li>
                                    <li><a href="blockchain.php">Blockchain</a></li>
                                    <li><a href="extended-reality.php">Extended Reality</a></li>
                                    <li><a href="protoyping.php">Prototyping</a></li>
                                    <li><a href="ux-dsign.php">UX Design</a></li> -->
                                </ul>
                            </li>
                            <li><a href="clients.php">clients</a></li>
                            <li><a href="our-team.php">Our Team</a></li>
                            <li><a href="contact-us.php">Conatct Us</a></li>
                            <li><a href="#" class="main-btn-red">Consult</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <div class="container-fluid banner p-0 position-relative">
        <div class="banner-slide">
            <div class="owl-carousel owl-theme banner-owl">
                <div class="item">
                    <img src="assets/banner-1.png">
                </div>
                <div class="item">
                    <img src="assets/earth-gf4a5db4fe_1920.jpg">
                </div>
            </div>
        </div>
        <h2 class="banner-text">Your remote-first<br>technology partner.</h2>
        <div class="client-cell py-5">
            <div class="container position-relative">
                <div class="row">
                    <div class="col-12 main-heaing small-heading">
                        <h2 class="text-center">We’ve built <span>Solutions</span> for...</h2>
                    </div>
                    <div class="col-12 service-wrap">
                        <div class="owl-carousel owl-theme client-owl">
                            <div class="item">
                                <img src="assets/client-logo/client-logo (1).png">
                            </div>
                            <div class="item">
                                <img src="assets/client-logo/client-logo (2).png">
                            </div>
                            <div class="item">
                                <img src="assets/client-logo/client-logo (3).png">
                            </div>
                            <div class="item">
                                <img src="assets/client-logo/client-logo (4).png">
                            </div>
                            <div class="item">
                                <img src="assets/client-logo/client-logo (5).png">
                            </div>
                            <div class="item">
                                <img src="assets/client-logo/client-logo (6).png">
                            </div>
                            <div class="item">
                                <img src="assets/client-logo/client-logo (3).png">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 pt-0 position-relative" style="overflow:hidden;">
        <img src="assets/service-bk.png" class="service-bk">
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2><span>Services</span> we can help you with</h2>
                </div>
                <div class="col-12 service-wrap">
                    <div class="owl-carousel owl-theme service-owl">
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <div class="icon-box">
                                        <img src="assets/service (1).png" class="icon-cell">
                                    </div>
                                    <h4>Mobile App Development</h4>
                                    <p>Deliver a seamless customer experience across multiple platforms with our full-cycle mobile app development services. Our agile solutions are available for Android, iOS, & Windows. </p>
                                    <a href="mobile-application-development.php">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <div class="icon-box">
                                        <img src="assets/service (2).png" class="icon-cell">
                                    </div>
                                    <h4>Custom Web Development</h4>
                                    <p>Create a unique web experience that connects users to your brand and encourages your target audience to trust your business. Build authority and thought leadership with custom web apps.</p>
                                    <a href="custom-web-development.php">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <div class="icon-box">
                                        <img src="assets/service (3).png" class="icon-cell">
                                    </div>
                                    <h4>DevOps as a Service</h4>
                                    <p>Meet digital disruptions head-on with our modern software engineering approach. Break down operational and developmental silos for optimal performance and effective collaboration.</p>
                                    <a href="devops.php">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <div class="icon-box">
                                        <img src="assets/service (2).png" class="icon-cell">
                                    </div>
                                    <h4>Product Discovery</h4>
                                    <p>We specialize in designing high impact user-centric mobile solutions that excites users, make lives easier, enhance brand reputations, and establish strong company-customer relationships. </p>
                                    <a href="product-discovery.php">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <div class="icon-box">
                                        <img src="assets/service (3).png" class="icon-cell">
                                    </div>
                                    <h4>Artificial Intelligence</h4>
                                    <p>We specialize in designing high impact user-centric mobile solutions that excites users, make lives easier, enhance brand reputations, and establish strong company-customer relationships. </p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <div class="icon-box">
                                        <img src="assets/service (2).png" class="icon-cell">
                                    </div>
                                    <h4>Internet of Things</h4>
                                    <p>We specialize in designing high impact user-centric mobile solutions that excites users, make lives easier, enhance brand reputations, and establish strong company-customer relationships. </p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <div class="icon-box">
                                        <img src="assets/service (3).png" class="icon-cell">
                                    </div>
                                    <h4>Blockchain</h4>
                                    <p>We specialize in designing high impact user-centric mobile solutions that excites users, make lives easier, enhance brand reputations, and establish strong company-customer relationships. </p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <div class="icon-box">
                                        <img src="assets/service (2).png" class="icon-cell">
                                    </div>
                                    <h4>Extended Reality</h4>
                                    <p>We specialize in designing high impact user-centric mobile solutions that excites users, make lives easier, enhance brand reputations, and establish strong company-customer relationships. </p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <div class="icon-box">
                                        <img src="assets/service (3).png" class="icon-cell">
                                    </div>
                                    <h4>Prototyping</h4>
                                    <p>We specialize in designing high impact user-centric mobile solutions that excites users, make lives easier, enhance brand reputations, and establish strong company-customer relationships. </p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="service-box">
                                <div class="service-cell">
                                    <div class="icon-box">
                                        <img src="assets/service (3).png" class="icon-cell">
                                    </div>
                                    <h4>UX Design</h4>
                                    <p>We specialize in designing high impact user-centric mobile solutions that excites users, make lives easier, enhance brand reputations, and establish strong company-customer relationships. </p>
                                    <a href="#">learn more <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid position-relative" style="overflow:hidden;">
        <div class="container position-relative">
            <div class="row py-6 border-top">
                <div class="owl-carousel owl-theme tec-owl">
                    <div class="item">
                        <img src="assets/python.png">
                        <p>PYTHON DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/React-icon.svg.png">
                        <p>REACT DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/2048px-Angular_full_color_logo.svg.png">
                        <p>ANGULAR DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/PHP-logo.svg.png">
                        <p>PHP DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/ntffgniiqfya5tvzbsol.webp">
                        <p>FRONTEND DEVELOPMENT</p>
                    </div>
                    <div class="item">
                        <img src="assets/1200px-Wordpress_Blue_logo.png">
                        <p>WORDPRESS DEVELOPMENT</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 work-block position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center text-white">Some of Our <span class="text-white">Finest Work</span></h2>
                </div>
                <div class="col-12 work-wrap">
                    <div class="grid-container">
                        <a class="work-img-cell item1">
                            <img src="assets/works/w-1 (1).png">
                            <div class="work-hover-block">
                                <div class="work-hover-cell">
                                    <h4>Project NAme</h4>
                                    <p>App UI Design</p>
                                </div>
                            </div>
                        </a>
                        <a class="work-img-cell item5">
                            <img src="assets/works/w-1 (3).png">
                            <div class="work-hover-block">
                                <div class="work-hover-cell">
                                    <h4>Project NAme</h4>
                                    <p>App UI Design</p>
                                </div>
                            </div>
                        </a>
                        <a class="work-img-cell item8">
                            <img src="assets/works/w-1 (4).png">
                            <div class="work-hover-block">
                                <div class="work-hover-cell">
                                    <h4>Project NAme</h4>
                                    <p>App UI Design</p>
                                </div>
                            </div>
                        </a>
                        <a class="work-img-cell item2">
                            <img src="assets/works/w-1 (2).png">
                            <div class="work-hover-block">
                                <div class="work-hover-cell">
                                    <h4>Project NAme</h4>
                                    <p>App UI Design</p>
                                </div>
                            </div>
                        </a>
                        <a class="work-img-cell item9">
                            <img src="assets/works/w-1 (7).png">
                            <div class="work-hover-block">
                                <div class="work-hover-cell">
                                    <h4>Project NAme</h4>
                                    <p>App UI Design</p>
                                </div>
                            </div>
                        </a>
                        <a class="work-img-cell item3">
                            <img src="assets/works/w-1 (8).png">
                            <div class="work-hover-block">
                                <div class="work-hover-cell">
                                    <h4>Project NAme</h4>
                                    <p>App UI Design</p>
                                </div>
                            </div>
                        </a>
                        <a class="work-img-cell item6">
                            <img src="assets/works/w-1 (6).png">
                            <div class="work-hover-block">
                                <div class="work-hover-cell">
                                    <h4>Project NAme</h4>
                                    <p>App UI Design</p>
                                </div>
                            </div>
                        </a>
                        <a class="work-img-cell item4">
                            <img src="assets/works/w-1 (9).png">
                            <div class="work-hover-block">
                                <div class="work-hover-cell">
                                    <h4>Project NAme</h4>
                                    <p>App UI Design</p>
                                </div>
                            </div>
                        </a>
                        <a class="work-img-cell item7">
                            <img src="assets/works/w-1 (10).png">
                            <div class="work-hover-block">
                                <div class="work-hover-cell">
                                    <h4>Project NAme</h4>
                                    <p>App UI Design</p>
                                </div>
                            </div>
                        </a>
                        <a class="work-img-cell item10">
                            <img src="assets/works/w-1 (8).png">
                            <div class="work-hover-block">
                                <div class="work-hover-cell">
                                    <h4>Project NAme</h4>
                                    <p>App UI Design</p>
                                </div>
                            </div>
                        </a>
                    </div>

                </div>
                <div class="show-mor-box">
                    <button class="main-btn-white ">Discover More Projects</button>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative process">
        <div class="process-bk">
            <img src="assets/proccss-bk.png">
        </div>
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 main-heaing">
                    <h2 class="text-center text-white">Mariana 2 Mars <span class="text-white">Process</span></h2>
                </div>
                <div class="col-12 mb-5" style="overflow: hidden;">
                    <div class="process-btn-cell">
                        <button class="tab-links active-a" data-id="discovery">Discovery</button>
                        <button class="tab-links" data-id="strategicarchitecture">STRATEGIC ARCHITECTURE</button>
                        <button class="tab-links" data-id="uidesign">UI DESIGN</button>
                        <button class="tab-links" data-id="programming">PROGRAMMING</button>
                        <button class="tab-links" data-id="qualitycontroll">QUALITY CONTROL</button>
                        <button class="tab-links" data-id="launch">LAUNCH</button>
                    </div>
                </div>
                <div class="col-12 tab-content active" data-id="discovery">
                    <div class=" process-content-cell">
                        <div class="process-box">
                            <!-- <h4>Discovery</h4> -->
                            <div class="content">
                                <p>Discovery is the first phase of any good web development project. It’s about learning your organization’s goals, your target users, and the desired features and functionality of your site.</p>
                            </div>
                        </div>
                        <img src="assets/procss-1.png">
                    </div>
                </div>
                <div class="col-12 tab-content" data-id="strategicarchitecture">
                    <div class=" process-content-cell">
                        <div class="process-box">
                            <!-- <h4>strategic architecture</h4> -->
                            <div class="content">
                                <p>The first phase of a good web development project is Discovery. In short, it’s the process of learning. M2M needs to learn as much as we can about you, your organization’s goals and users, and the required features and functionality of the site. With all this information in hand, we begin to lay the foundation for an optimal website. The Discovery phase will begin with information gathering. Conversations between our Project Management, User Experience and Development teams, and key stakeholders at your end, will further define the goals of the new website, determine the key user personas, and detail the desired functionality for the finished product.</p>
                            </div>
                        </div>
                        <img src="assets/image-wireframe.jpg">
                    </div>
                </div>
                <div class="col-12 tab-content" data-id="uidesign">
                    <div class=" process-content-cell">
                        <div class="process-box">
                            <!-- <h4>UI Design</h4> -->
                            <div class="content">
                                <p>The first phase of a good web development project is Discovery. In short, it’s the process of learning. M2M needs to learn as much as we can about you, your organization’s goals and users, and the required features and functionality of the site. With all this information in hand, we begin to lay the foundation for an optimal website. The Discovery phase will begin with information gathering. Conversations between our Project Management, User Experience and Development teams, and key stakeholders at your end, will further define the goals of the new website, determine the key user personas, and detail the desired functionality for the finished product.</p>
                            </div>
                        </div>
                        <img src="assets/UI-design.jpg">
                    </div>
                </div>
                <div class="col-12 tab-content" data-id="programming">
                    <div class=" process-content-cell">
                        <div class="process-box">
                            <!-- <h4>Programming</h4> -->
                            <div class="content">
                                <p>The first phase of a good web development project is Discovery. In short, it’s the process of learning. M2M needs to learn as much as we can about you, your organization’s goals and users, and the required features and functionality of the site. With all this information in hand, we begin to lay the foundation for an optimal website. The Discovery phase will begin with information gathering. Conversations between our Project Management, User Experience and Development teams, and key stakeholders at your end, will further define the goals of the new website, determine the key user personas, and detail the desired functionality for the finished product.</p>
                            </div>
                        </div>
                        <img src="assets/image-dev.jpg">
                    </div>
                </div>
                <div class="col-12 tab-content" data-id="qualitycontroll">
                    <div class=" process-content-cell">
                        <div class="process-box">
                            <!-- <h4>quality control</h4> -->
                            <div class="content">
                                <p>The first phase of a good web development project is Discovery. In short, it’s the process of learning. M2M needs to learn as much as we can about you, your organization’s goals and users, and the required features and functionality of the site. With all this information in hand, we begin to lay the foundation for an optimal website. The Discovery phase will begin with information gathering. Conversations between our Project Management, User Experience and Development teams, and key stakeholders at your end, will further define the goals of the new website, determine the key user personas, and detail the desired functionality for the finished product.</p>
                            </div>
                        </div>
                        <img src="assets/image-testing.jpg">
                    </div>
                </div>
                <div class="col-12 tab-content" data-id="launch">
                    <div class=" process-content-cell">
                        <div class="process-box">
                            <!-- <h4>Launch</h4> -->
                            <div class="content">
                                <p>The first phase of a good web development project is Discovery. In short, it’s the process of learning. M2M needs to learn as much as we can about you, your organization’s goals and users, and the required features and functionality of the site. With all this information in hand, we begin to lay the foundation for an optimal website. The Discovery phase will begin with information gathering. Conversations between our Project Management, User Experience and Development teams, and key stakeholders at your end, will further define the goals of the new website, determine the key user personas, and detail the desired functionality for the finished product.</p>
                            </div>
                        </div>
                        <img src="assets/image-golive.jpg">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-6 position-relative" style="overflow:hidden;">
        <img src="assets/counter-bk.png" class="counter-bk">
        <div class="container position-relative">
            <div class="row align-items-center">
                <div class="col-12 col-md-6">
                    <div class="col-12 main-heaing">
                        <h2>We’re <span>Creative</span> Agency</h2>
                    </div>
                    <div class="col-12 service-wrap">
                        <div class="content">
                            <p>From the ocean’s deepest abyss to the furthest reaches of space, humans instinctively crave exploration. At Mariana 2 Mars, we understand that exploring and discovering the core purpose, mission, and vision of your business is key to building successful technical solutions.</p>
                        </div>
                        <ul class="about-tag">
                            <li>#digitalcreativeagency</li>
                            <li>#professionalproblemsolutions</li>
                            <li>#creativewebsitesolutions</li>
                        </ul>
                    </div>
                </div>
                <div class="col-12 col-md-6 about-counter-cell ">
                    <div class="about-counter">
                        <div class="d-flex align-items-center justify-content-center">
                            <div>
                                <p style="background: #F0EAFF;"><img src="assets/counter (3).png"></p>
                                <h4>500+</h4>
                                <h6>Satisfied Clients</h6>
                            </div>
                        </div>
                        <div class=" d-flex align-items-center justify-content-center">
                            <div>
                                <p style="background: #FFF3EE;"><img src="assets/counter (4).png"></p>
                                <h4>50+</h4>
                                <h6>Specialist</h6>
                            </div>
                        </div>

                    </div>
                    <div class="about-counter">
                        <div class=" d-flex align-items-center justify-content-center">
                            <div>
                                <p style="background: #FFF3EE;"><img src="assets/counter (2).png"></p>
                                <h4>1000+</h4>
                                <h6>Completed Projects </h6>
                            </div>
                        </div>
                        <div class=" d-flex align-items-center justify-content-center">
                            <div>
                                <p style="background: #E5FAF5;"><img src="assets/counter (1).png"></p>
                                <h4>20+</h4>
                                <h6>Year of Exprience</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid rnd-main">
        <div class="container">
            <div class="row py-6 px-6 position-relative" style="background:#F51720; ;">
                <img src="assets/image 69.png" class="rnd-bk">
                <div class="col-12 col-md-6 position-relative">
                    <div class="col-12 main-heaing">
                        <h2 class="text-white">Reduce <i>R&D COST</i> Without Sacrificing <span class="text-white">Talent and Expertise.</span></h2>
                    </div>
                    <div class="rnd-con mb-5 pb-5">
                        <p>We provide top talent at a fraction of the cost with remote teams worldwide, including hubs in India and Turkey.</p>
                    </div>
                </div>
                <div class="col-12 col-md-6 text-right position-relative">
                    <button class="main-btn-white border-white">Work With Us</button>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid rnd-wrap">
        <div class="container">
            <div class="row py-6 px-6">
                <div class="col-12">
                    <div class="rnd-cell">
                        <div class="rnd-box">
                            <img src="assets/rnd (2).png">
                            <div class="rnd-box-con">
                                <h4>GLOBAL RESOURCES</h4>
                                <p>From our head office in Ottawa, Canada to remote implementation teams worldwide, we provide customers with diverse expertise.</p>
                            </div>
                        </div>
                        <div class="rnd-box">
                            <img src="assets/rnd (3).png">
                            <div class="rnd-box-con">
                                <h4>REMOTE FIRST</h4>
                                <p>Our diverse and distributed remote team increases efficiency and gives your business access to the most talented and experienced resources.</p>
                            </div>
                        </div>
                        <div class="rnd-box">
                            <img src="assets/rnd (1).png">
                            <div class="rnd-box-con">
                                <h4>WE KNOW BUSINESS</h4>
                                <p>WWe build software—and relationships. Our Ottawa-based leadership team takes the time to get to know your organizations’ purpose, mission and vision.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid pb-6">
        <div class="container">
            <div class="row">
                <div class="col-12 d-md-flex align-items-center mb-5">
                    <div class="col-12 col-md-12 mb-5 mb-md-0">
                        <div class="col-12 main-heaing">
                            <h2 class="text-center">Alone we can do so little; <span>Together</span> we can do so much.</h2>
                        </div>
                        <div class="content text-center">
                            <p>We work with you to achieve the vision you have for your business, website, and customer experiences.</p>
                        </div>
                    </div>
                    <!-- <div class="col-12 col-md-5 offset-md-3">
                        <ul class="team-tab">
                            <li>
                                <ul>
                                    <li class="tablinks active-a" data-id="managnent">Management</li>
                                    <li class="tablinks" data-id="designer">Designer</li>
                                    <li class="tablinks" data-id="appdveloper">App Developer</li>
                                </ul>
                            </li>
                            <li>
                                <ul>
                                    <li class="tablinks" data-id="fronted">Frontend</li>
                                    <li class="tablinks" data-id="backend">Backend</li>
                                    <li class="tablinks" data-id="businessdevelopmwnt">Business development</li>
                                </ul>
                            </li>
                        </ul>
                    </div> -->
                </div>
                <div class="col-12 tabcontent active" data-id="managnent">
                    <div class="team-box row ">
                        <div class="flip-card col-12 col-md-3 p-0">
                            <div class="flip-card-inner ">
                                <div class="flip-card-front">
                                    <div class="service-box">
                                        <div class="service-cell team-cell">
                                            <div class="img-box">
                                                <img src="assets/team (2).png">
                                            </div>
                                            <h4>REBECCA GARNER</h4>
                                            <p>CEO</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="flip-card-back">
                                    <div class="content" style="color: black !important;">
                                        <p>Rebecca’s first entrepreneurial effort began in her mid-20s, when she co-founded and raised investment for a niche resort project. That experience sparked her passion for business strategy, leading to her co-founding of four other companies in the tourism and technology sectors. Rebecca is a problem solver with a sharp perspective and creativity—qualities that are key to her success.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flip-card col-12 col-md-3 p-0">
                            <div class="flip-card-inner ">
                                <div class="flip-card-front">
                                    <div class="service-box">
                                        <div class="service-cell team-cell">

                                            <div class="img-box">
                                                <img src="assets/team (3).png">
                                            </div>
                                            <h4>TALIB KHAN</h4>
                                            <p>COO</p>

                                        </div>
                                    </div>
                                </div>
                                <div class="flip-card-back">
                                    <div class="content" style="color: black !important;">
                                        <p>Talib has successfully established six companies, taking them from conception to commercialization. He prides himself on continually developing and learning as an individual and believes his virtue lies in inspiring strong teams, scaling companies, and creatively solving problems in specific niches. Talib is not only known for his ambition—his focus on building strong, trusting business relationships is what distinguishes him from others.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flip-card col-12 col-md-3 p-0">
                            <div class="flip-card-inner ">
                                <div class="flip-card-front">
                                    <div class="service-box">
                                        <div class="service-cell team-cell">

                                            <div class="img-box">
                                                <img src="assets/team (5).png">
                                            </div>
                                            <h4>YASSIN MOHAMED</h4>
                                            <p>CTO</p>

                                        </div>
                                    </div>
                                </div>
                                <div class="flip-card-back">
                                    <div class="content" style="color: black !important;">
                                        <p>Yassin is responsible for navigating M2M’s long-term technology vision. He manages all aspects of technical decision-making, including oversight of the architecture, development, and design of UI interfaces. With over 25 years of proven technical experience developing technology initiatives for organizations of all sizes and scopes, Yassin has a keen interest in digital marketplace developments from scratch within the fintech and AI industries.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flip-card col-12 col-md-3 p-0">
                            <div class="flip-card-inner ">
                                <div class="flip-card-front">
                                    <div class="service-box">
                                        <div class="service-cell team-cell">
                                            <div class="img-box">
                                                <img src="assets/team (6).png">
                                            </div>
                                            <h4>KUMARESH KAR</h4>
                                            <p>CPO</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="flip-card-back">
                                    <div class="content" style="color: black !important;">
                                        <p>Kumar brings more than 16 years of rich experience in the IT industry, including working for multiple multinational companies as a senior manager. In addition to his Master of Computer Science and MBA in International Business, Kumar also specializes in product design and conceptualization and product life cycle management.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flip-card col-12 col-md-3 p-0">
                            <div class="flip-card-inner ">
                                <div class="flip-card-front">
                                    <div class="service-box">
                                        <div class="service-cell team-cell">
                                            <div class="img-box">
                                                <img src="assets/team (7).png">
                                            </div>
                                            <h4>DANIYAL ZAFAR</h4>
                                            <p>CMO</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="flip-card-back">
                                    <div class="content" style="color: black !important;">
                                        <p>Daniyal brings over a decade of growth marketing, branding, and strategic vision experience to Mariana 2 Mars. His robust marketing leadership, brand revitalization, data-driven planning, and overall execution of creative marketing strategies has enabled him to grow companies to up to $50+ million. Daniyal has built a reputation for excellence in Canadian business circles—as an integral part of M2M’s leadership team, he is focused on ensuring M2M’s clients receive successful marketing and growth strategies to take their organizations to the next level.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid testi py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 offset-md-3">
                    <div class="col-12 main-heaing">
                        <h2 class="text-center"><span>Trusted</span> By Clients</h2>
                    </div>
                    <div class="col-12">
                        <div class="owl-carousel owl-theme testi-owl">
                            <div class="item">
                                <div class="testi-content">
                                    <p>They're very willing to assemble the team that we ask for if we have certain preferences.</p>
                                </div>
                                <div class="testi-user">
                                    <img src="assets/imansyah-muhamad-putera-n4KewLKFOZw-unsplash.jpg">
                                    <h5>Thiago Alcantara</h5>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testi-content">
                                    <p>Their project management style and tools are both flexible.</p>
                                </div>
                                <div class="testi-user">
                                    <img src="assets/joseph-gonzalez-iFgRcqHznqg-unsplash.jpg">
                                    <h5>George Levy</h5>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testi-content">
                                    <p>I am glad I found M2M and I credit them for a lot of the success I have had.</p>
                                </div>
                                <div class="testi-user">
                                    <img src="assets/jurica-koletic-7YVZYZeITc8-unsplash.jpg">
                                    <h5>Ze Wei Wong</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="ontainer-fluid position-relative">
        <div class="bk-img-box">
            <img src="assets/think-big-bk.png" style="width:100%; height:100%; object-fit: cover;">
        </div>
        <div class="container position-relative">
            <div class="row">
                <div class="col-12 col-md-4 think-lft">
                    <h1>Think big</h1>
                    <div class="content">
                        <p>Let your imagination guide your design and let our diverse team of experts transform your vision into reality. From custom web and mobile app development to innovations in artificial intelligence and blockchain technology, we have the tools, experience, and expertise to take your organization to new heights.</p>
                    </div>
                </div>
                <div class="col-12 col-md-7 offset-md-1 think-rt">
                    <video id="b12b2e59-111d-caca-e3ab-03a4e02744b4-video" autoplay="" loop="" style="background-image:url('https://global-uploads.webflow.com/625593a881b8ebd169835ca5/628cd444f8f1e8b4fa648677_Group By List - Screen-poster-00001.jpg');width: 100%;height: 100%; background: white; " muted="" playsinline="" data-wf-ignore="true" data-object-fit="cover">
                        <source src="https://global-uploads.webflow.com/625593a881b8ebd169835ca5/628cd444f8f1e8b4fa648677_Group By List - Screen-transcode.mp4" data-wf-ignore="true">
                        <source src="https://global-uploads.webflow.com/625593a881b8ebd169835ca5/628cd444f8f1e8b4fa648677_Group By List - Screen-transcode.webm" data-wf-ignore="true">
                    </video>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid py-5" style="background: #42424A;">
        <div class="container">
            <div class="row">
                <div class="con-box">
                    <div class="con-cell">
                        <h3>Ready to launch your next successful project? </h3>
                        <p>call us now</p>
                        <h3>(514) 910-1418</h3>
                    </div>
                    <button class="main-btn-white border-white">Consult</button>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid footer py-6">
        <div class="container">
            <div class="row">
                <div class="col-12 ft-top mb-5 d-md-flex align-items-center">
                    <img src="assets/logo.png" class="logo">
                    <h3>Modern Solutionsd For Creative <span>Agency</span></h3>
                </div>
                <div class="col-12 col-md-5 get-in">
                    <h4>Let’s Connect!</h4>
                    <p>Contact us today to discover how our customized design solutions can work for you!</p>
                    <div class="sub-frm-cell">
                        <input type="text" placeholder="Enter Mobile Number">
                        <button>Subscribe</button>
                    </div>
                </div>
                <div class="col-12 col-md-7 menu-link pl-md-5 ">
                    <div class="row">
                        <div class="col-md-7 mt-5 mt-md-0">
                            <h5>Services</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-md-2">
                                    <ul>
                                    <li><a href="mobile-application-development.php">Mobile App Development</a></li>
                                    <li><a href="custom-web-development.php">Custom Web Development</a></li>
                                    
                                        <!-- <li><a href="artificial-inteligence.php">Artificial Intelligence</a></li> -->
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                    <li><a href="devops.php">DevOps as a Service</a></li>
                                    <li><a href="marketings.php">Marketing</a></li>
                                        <!-- <li><a href="intrnet-things.php">Internet of Things</a></li>
                                        <li><a href="blockchain.php">Blockchain</a></li>
                                        <li><a href="extended-reality.php">Extended Reality</a></li>
                                        <li><a href="protoyping.php">Prototyping</a></li>
                                        <li><a href="ux-dsign.php">UX Design</a></li> -->
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-5  pl-md-5 mt-5 mt-md-0">
                            <h5>Links</h5>
                            <ul class="d-md-flex justify-content-between">
                                <li class="pr-2">
                                    <ul>
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about-us.php">About Us</a></li>
                                        <li><a href="service.php">Services</a></li>
                                    </ul>
                                </li>
                                <li class="pl-md-2">
                                    <ul>
                                        <li><a href="clients.php">clients</a></li>
                                        <li><a href="our-team.php">Our Team</a></li>
                                        <li><a href="contact-us.php">Conatct Us</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="footer-social d-md-flex align-items-center justify-content-between pt-5 mt-5 rounded">
                    <p class="mb-0" style="font-size:15px;">Copyright @ 2014 - 2022 </a></p>
                    <p class="mb-0" style=" font-size:15px;">
                        <a style=" margin-right:10px;margin-left:10px;"><i class="fab fa-facebook"></i></a>
                        <a style="  margin-right:10px;"><i class="fab fa-instagram"></i></a>
                        <a><i class="fab fa-twitter"></i></a>
                    </p>

                </div>
            </div>
        </div>
    </div>
</body>
<script>
    $('.service-owl').owlCarousel({
        loop: true,
        margin: 60,

        dots: false,
        responsive: {
            0: {
                items: 1,
                nav: false,
            },
            600: {
                items: 1,
                nav: false,
            },
            1000: {
                items: 3,
                nav: true,
            }
        }
    })

    $('.client-owl').owlCarousel({
        loop: true,
        margin: 30,
        nav: false,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 6
            }
        }
    })

    $('.banner-owl').owlCarousel({
        loop: true,
        autoplay: true,
        autoplayTimeout: 4000,
        margin: 0,
        nav: false,
        dots: false,
        animateOut: 'fadeOut',
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })

    $('.testi-owl').owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 4000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
    $('.tec-owl').owlCarousel({
        loop: true,
        margin: 30,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 6
            }
        }
    })
    $(document).ready(function() {
        $('.tablinks').click(function() {
            $(".tabcontent").removeClass('active');
            $(".tabcontent[data-id='" + $(this).attr('data-id') + "']").addClass("active");
            $(".tablinks").removeClass('active-a');
            $(this).addClass('active-a');
        });
        $('.tab-links').click(function() {
            $(".tab-content").removeClass('active');
            $(".tab-content[data-id='" + $(this).attr('data-id') + "']").addClass("active");
            $(".tab-links").removeClass('active-a');
            $(this).addClass('active-a');
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('.has-drop').click(function() {
            if ($(".sub-menu[data-id='" + $(this).attr('data-id') + "']").hasClass("active")) {
                $(".sub-menu").slideUp().removeClass('active');
                $(".has-drop").removeClass('active-a');
            } else {
                $(".sub-menu").slideUp().removeClass('active');
                $(".sub-menu[data-id='" + $(this).attr('data-id') + "']").slideDown().addClass("active");
                $(".has-drop").removeClass('active-a');
                $(this).parent().find(".has-drop").addClass('active-a');
            }
        });
    });
</script>

</html>